# DataPulse — Team 2: Store & Products

زیرسیستم تیم دوم پروژه DataPulse: فروشگاه و محصولات.

## موجودیت‌ها
- `stores`
- `categories`
- `products`
- `inventory`

## اهداف
- طراحی مدل داده تا 3NF
- تعریف PK/FK و محدودیت‌های داده
- درج 10 تا 20 رکورد نمونه در هر جدول
- یک کوئری تحلیلی با JOIN حداقل 3 جدول
- آماده‌سازی Indexها و سنجش عملکرد با EXPLAIN ANALYZE
- بررسی Indexهای بلااستفاده
- شناسایی Queryهای کند
- طراحی Materialized View برای گزارش فروش ماهانه
- نمونه Queryهای Window Function، CTE و ROLLUP/CUBE برای جلسه سوم

## ترتیب اجرا
1. `sql/01_create_tables.sql`
2. `sql/02_insert_data.sql`
3. `sql/03_analysis_queries.sql`
4. `indexes/01_index_benchmarks.sql`
5. `views/01_monthly_sales_materialized_view.sql`
6. `sql/05_session3_advanced_queries.sql`

> زمان‌های واقعی اجرای Queryها باید روی دیتابیس خودتان با `EXPLAIN ANALYZE` اندازه‌گیری و در `reports/execution_times.md` ثبت شوند.
