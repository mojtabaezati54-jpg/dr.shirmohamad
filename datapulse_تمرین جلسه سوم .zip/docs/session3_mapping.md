# Session 3 Mapping

## Required from the professor
1. Top 10 customers — included.
2. Abandoned carts — included.
3. Monthly sales trend with LAG — included.
4. Product conversion — included.
5. At least 5 Window Functions — included: ROW_NUMBER, RANK, DENSE_RANK, LAG, LEAD.
6. At least 3 CTEs — included.
7. ROLLUP — included.
8. CUBE — included.
9. Full-Text Search — included.
10. EXPLAIN ANALYZE — included.
11. At least 3 new indexes — included.
12. Materialized View — existing Team 2 view file from the previous package remains applicable.

## Cross-team dependency
Exercises 1-4 require `users`, `orders`, `order_items`, and `clickstream` in the shared database. The Team 2 repository does not own all of these entities. Execute those exercises after integrating the other teams' schemas.
