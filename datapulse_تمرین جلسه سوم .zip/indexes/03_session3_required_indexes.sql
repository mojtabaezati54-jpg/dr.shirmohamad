-- Session 3: at least 3 NEW indexes based directly on the professor's queries.
-- Measure each relevant query with EXPLAIN ANALYZE before and after.

-- 1) Exercise 1: users + orders filtered by user/status and ordered by date
CREATE INDEX IF NOT EXISTS idx_orders_user_status_created
ON orders (user_id, status, created_at DESC);

-- 2) Exercise 2: clickstream abandoned-cart filtering
CREATE INDEX IF NOT EXISTS idx_clickstream_action_product_user
ON clickstream (action, product_id, user_id);

-- 3) Exercise 4: product conversion via order_items
CREATE INDEX IF NOT EXISTS idx_order_items_product_order
ON order_items (product_id, order_id);

-- Bonus: Exercise 3 monthly sales date/status filtering
CREATE INDEX IF NOT EXISTS idx_orders_status_created_at
ON orders (status, created_at);

ANALYZE orders;
ANALYZE clickstream;
ANALYZE order_items;
ANALYZE products;
