# Session 3 — EXPLAIN ANALYZE Measurements

> Fill this file with REAL values from PostgreSQL. Do not invent execution times.

## Exercise 1 — Top 10 customers
Before index:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

After index `idx_orders_user_status_created`:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

## Exercise 2 — Abandoned carts
Before index:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

After index `idx_clickstream_action_product_user`:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

## Exercise 3 — Monthly sales
Before index:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

After index `idx_orders_status_created_at`:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

## Exercise 4 — Product conversion
Before index:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

After index `idx_order_items_product_order`:
- Planning Time: ___ ms
- Execution Time: ___ ms
- Plan summary: ___

### Formula
Improvement % = ((Before - After) / Before) × 100

A small dataset may legitimately show little improvement because PostgreSQL can prefer a sequential scan.
