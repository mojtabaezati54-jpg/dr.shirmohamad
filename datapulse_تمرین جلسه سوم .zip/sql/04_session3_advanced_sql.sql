-- DataPulse Team 2 — Session 3
-- PostgreSQL 17
--
-- IMPORTANT:
-- Exercises 1-4 from the professor use cross-team tables:
-- users, orders, order_items, clickstream.
-- These tables must exist in the shared DataPulse database.
--
-- Assumed columns from the professor's specification:
-- users(user_id, name, ...)
-- orders(order_id, user_id, total_amount, status, created_at, ...)
-- order_items(order_id, product_id, quantity, unit_price, discount)
-- clickstream(user_id, product_id, action, occurred_at, ...)
-- Team 2 tables: stores, categories, products, inventory.

-- ============================================================
-- EXERCISE 1: Top 10 users by total purchase
-- ============================================================
SELECT
    u.user_id,
    u.name,
    SUM(o.total_amount) AS total_purchase,
    COUNT(o.order_id) AS order_count,
    ROUND(AVG(o.total_amount), 2) AS avg_order_amount
FROM users u
JOIN orders o ON o.user_id = u.user_id
WHERE o.status IN ('paid', 'completed', 'delivered')
GROUP BY u.user_id, u.name
ORDER BY total_purchase DESC
LIMIT 10;

-- ============================================================
-- EXERCISE 2: Abandoned carts
-- ============================================================
SELECT DISTINCT
    cs.user_id,
    cs.product_id,
    p.name AS product_name
FROM clickstream cs
JOIN products p ON p.product_id = cs.product_id
LEFT JOIN (
    SELECT DISTINCT
        o.user_id,
        oi.product_id
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.order_id
    WHERE o.status IN ('paid', 'completed', 'delivered')
) purchased
ON purchased.user_id = cs.user_id
AND purchased.product_id = cs.product_id
WHERE cs.action = 'add_to_cart'
  AND purchased.product_id IS NULL
ORDER BY cs.user_id, cs.product_id;

-- ============================================================
-- EXERCISE 3: Monthly sales trend + percentage change
-- ============================================================
WITH monthly_sales AS (
    SELECT
        DATE_TRUNC('month', o.created_at)::date AS sales_month,
        SUM(o.total_amount) AS monthly_sales
    FROM orders o
    WHERE o.status IN ('paid', 'completed', 'delivered')
      AND o.created_at >= DATE_TRUNC('year', CURRENT_DATE)
      AND o.created_at < DATE_TRUNC('year', CURRENT_DATE) + INTERVAL '1 year'
    GROUP BY DATE_TRUNC('month', o.created_at)::date
),
sales_with_previous AS (
    SELECT
        sales_month,
        monthly_sales,
        LAG(monthly_sales) OVER (ORDER BY sales_month) AS previous_month_sales
    FROM monthly_sales
)
SELECT
    sales_month,
    ROUND(monthly_sales, 2) AS monthly_sales,
    ROUND(previous_month_sales, 2) AS previous_month_sales,
    CASE
        WHEN previous_month_sales IS NULL OR previous_month_sales = 0 THEN NULL
        ELSE ROUND(
            ((monthly_sales - previous_month_sales) / previous_month_sales) * 100,
            2
        )
    END AS pct_change_from_previous_month
FROM sales_with_previous
ORDER BY sales_month;

-- ============================================================
-- EXERCISE 4: Product conversion rate = purchases / views
-- ============================================================
WITH product_views AS (
    SELECT
        product_id,
        COUNT(*) AS view_count
    FROM clickstream
    WHERE action = 'view'
    GROUP BY product_id
),
product_purchases AS (
    SELECT
        oi.product_id,
        SUM(oi.quantity) AS purchase_count
    FROM order_items oi
    JOIN orders o ON o.order_id = oi.order_id
    WHERE o.status IN ('paid', 'completed', 'delivered')
    GROUP BY oi.product_id
)
SELECT
    p.product_id,
    p.name AS product_name,
    COALESCE(v.view_count, 0) AS views,
    COALESCE(pp.purchase_count, 0) AS purchases,
    CASE
        WHEN COALESCE(v.view_count, 0) = 0 THEN 0
        ELSE ROUND(
            (COALESCE(pp.purchase_count, 0)::numeric / v.view_count) * 100,
            2
        )
    END AS conversion_rate_pct
FROM products p
LEFT JOIN product_views v ON v.product_id = p.product_id
LEFT JOIN product_purchases pp ON pp.product_id = p.product_id
ORDER BY conversion_rate_pct DESC, p.name;

-- ============================================================
-- WINDOW FUNCTIONS — 5 required examples
-- ============================================================

-- 1) ROW_NUMBER
SELECT
    p.store_id,
    p.product_id,
    p.name,
    p.created_at,
    ROW_NUMBER() OVER (
        PARTITION BY p.store_id
        ORDER BY p.created_at DESC, p.product_id DESC
    ) AS row_num
FROM products p;

-- 2) RANK
SELECT
    c.name AS category_name,
    p.name AS product_name,
    p.price_amount,
    RANK() OVER (
        PARTITION BY p.category_id
        ORDER BY p.price_amount DESC
    ) AS price_rank
FROM products p
JOIN categories c ON c.category_id = p.category_id;

-- 3) DENSE_RANK
SELECT
    s.name AS store_name,
    p.name AS product_name,
    i.quantity,
    DENSE_RANK() OVER (
        PARTITION BY p.store_id
        ORDER BY i.quantity DESC
    ) AS stock_rank
FROM products p
JOIN stores s ON s.store_id = p.store_id
JOIN inventory i ON i.product_id = p.product_id;

-- 4) LAG
SELECT
    store_id,
    product_id,
    name,
    price_amount,
    LAG(price_amount) OVER (
        PARTITION BY store_id
        ORDER BY product_id
    ) AS previous_product_price
FROM products;

-- 5) LEAD
SELECT
    category_id,
    product_id,
    name,
    price_amount,
    LEAD(price_amount) OVER (
        PARTITION BY category_id
        ORDER BY product_id
    ) AS next_product_price
FROM products;

-- ============================================================
-- CTE — 3 required examples
-- ============================================================

-- CTE 1
WITH store_inventory AS (
    SELECT
        s.store_id,
        s.name AS store_name,
        SUM(i.quantity * p.price_amount * p.exchange_rate_to_irr) AS inventory_value_irr
    FROM stores s
    JOIN products p ON p.store_id = s.store_id
    JOIN inventory i ON i.product_id = p.product_id
    GROUP BY s.store_id, s.name
)
SELECT
    store_id,
    store_name,
    ROUND(inventory_value_irr, 0) AS inventory_value_irr
FROM store_inventory
ORDER BY inventory_value_irr DESC;

-- CTE 2
WITH category_stats AS (
    SELECT
        category_id,
        COUNT(*) AS product_count,
        AVG(price_amount) AS avg_price
    FROM products
    GROUP BY category_id
)
SELECT
    c.category_id,
    c.name,
    cs.product_count,
    ROUND(cs.avg_price, 2) AS avg_price
FROM category_stats cs
JOIN categories c ON c.category_id = cs.category_id
ORDER BY cs.avg_price DESC;

-- CTE 3
WITH low_stock AS (
    SELECT
        product_id,
        quantity,
        reorder_level
    FROM inventory
    WHERE quantity <= reorder_level
)
SELECT
    p.product_id,
    p.name,
    s.name AS store_name,
    low_stock.quantity,
    low_stock.reorder_level
FROM low_stock
JOIN products p ON p.product_id = low_stock.product_id
JOIN stores s ON s.store_id = p.store_id
ORDER BY low_stock.quantity ASC;

-- ============================================================
-- ROLLUP
-- ============================================================
SELECT
    s.name AS store_name,
    c.name AS category_name,
    COUNT(p.product_id) AS product_count,
    ROUND(AVG(p.price_amount), 2) AS avg_price
FROM stores s
JOIN products p ON p.store_id = s.store_id
JOIN categories c ON c.category_id = p.category_id
GROUP BY ROLLUP (s.name, c.name)
ORDER BY s.name NULLS LAST, c.name NULLS LAST;

-- ============================================================
-- CUBE
-- ============================================================
SELECT
    s.name AS store_name,
    c.name AS category_name,
    COUNT(p.product_id) AS product_count,
    ROUND(SUM(i.quantity * p.price_amount * p.exchange_rate_to_irr), 0) AS inventory_value_irr
FROM stores s
JOIN products p ON p.store_id = s.store_id
JOIN categories c ON c.category_id = p.category_id
JOIN inventory i ON i.product_id = p.product_id
GROUP BY CUBE (s.name, c.name)
ORDER BY s.name NULLS LAST, c.name NULLS LAST;

-- ============================================================
-- FULL-TEXT SEARCH
-- ============================================================
ALTER TABLE products
    ADD COLUMN IF NOT EXISTS search_vector tsvector;

UPDATE products
SET search_vector = to_tsvector(
    'simple',
    COALESCE(name, '') || ' ' || COALESCE(description, '')
);

CREATE INDEX IF NOT EXISTS idx_products_search_vector
ON products USING GIN (search_vector);

SELECT
    product_id,
    name,
    ts_rank(
        search_vector,
        plainto_tsquery('simple', 'gaming keyboard')
    ) AS rank
FROM products
WHERE search_vector @@ plainto_tsquery('simple', 'gaming keyboard')
ORDER BY rank DESC;

-- ============================================================
-- EXPLAIN ANALYZE example
-- ============================================================
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    s.name AS store_name,
    c.name AS category_name,
    p.name AS product_name,
    i.quantity
FROM stores s
JOIN products p ON p.store_id = s.store_id
JOIN categories c ON c.category_id = p.category_id
JOIN inventory i ON i.product_id = p.product_id
WHERE p.is_active = TRUE
ORDER BY p.price_amount DESC;
