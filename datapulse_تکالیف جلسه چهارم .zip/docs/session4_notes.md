# Session 4 Notes — Team 2

## What the professor requested

1. Analyze the Top Customers query with EXPLAIN ANALYZE.
2. Design composite indexes for recurring queries.
3. Create a partial index for active products with positive inventory.
4. Create a covering index for the monthly sales report.
5. Monitor index usage with `pg_stat_user_indexes`.
6. Monitor table scans with `pg_stat_user_tables`.
7. Monitor slow queries with `pg_stat_statements`.
8. Understand/rebuild indexes with `REINDEX`.

## Important PostgreSQL design correction

The requirement "one partial index on products for active products AND positive inventory" is not directly possible in a normalized schema when `quantity` lives in the separate `inventory` table. PostgreSQL partial-index predicates cannot reference another table.

Therefore the correct normalized implementation is:
- partial index on `products` with `WHERE is_active = TRUE`
- partial index on `inventory` with `WHERE quantity > 0`

The query then joins both indexed relations.

## Index types covered

- B-Tree: default and used for the composite indexes.
- GIN: already used by the project's Full-Text Search from Session 3.
- Partial: active products and positive inventory.
- Covering: `orders(created_at) INCLUDE (store_id, total_amount)`.
- BRIN/GiST/Hash: concepts covered in class; use only when workload/data distribution justifies them.
