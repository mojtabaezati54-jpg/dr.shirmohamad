-- DataPulse Team 2 — Session 4 index definitions
-- Create AFTER collecting baseline EXPLAIN ANALYZE results.

-- ============================================================
-- 1) Composite index for Top Customers / user + status + date
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_user_status_created_s4
ON orders (user_id, status, created_at DESC);

-- ============================================================
-- 2) Composite index for status + created_at reports
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_status_created_s4
ON orders (status, created_at DESC);

-- ============================================================
-- 3) Team 2 composite index:
-- store + category + price
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_products_store_category_price_s4
ON products (store_id, category_id, price_amount DESC)
WHERE is_active = TRUE;

-- ============================================================
-- 4) Partial index for active products
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_products_active_s4
ON products (store_id, category_id, price_amount DESC)
WHERE is_active = TRUE;

-- ============================================================
-- 5) Partial index for positive inventory
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_inventory_positive_stock_s4
ON inventory (product_id)
WHERE quantity > 0;

-- ============================================================
-- 6) Covering index for monthly sales
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_orders_monthly_sales_covering_s4
ON orders (created_at)
INCLUDE (store_id, total_amount);

-- Refresh planner statistics after creating indexes.
ANALYZE orders;
ANALYZE products;
ANALYZE inventory;
