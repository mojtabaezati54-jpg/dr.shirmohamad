# Session 4 — EXPLAIN ANALYZE Report

**Important:** The numbers below must be filled from the actual PostgreSQL 17 database. Do not invent them.

## Exercise 1 — Top Customers

### Before indexes
- Planning Time: ___ ms
- Execution Time: ___ ms
- Main scan: ___
- Notes: ___

### After `idx_orders_user_status_created_s4`
- Planning Time: ___ ms
- Execution Time: ___ ms
- Main scan: ___
- Notes: ___

### Improvement
`((Before - After) / Before) * 100 = ___ %`

---

## Exercise 2 — Composite indexes

### Query A: `(user_id, created_at)`
Before: ___ ms  
After: ___ ms  
Plan before: ___  
Plan after: ___

### Query B: `(status, created_at)`
Before: ___ ms  
After: ___ ms  
Plan before: ___  
Plan after: ___

### Query C: `(store_id, category_id, price_amount)`
Before: ___ ms  
After: ___ ms  
Plan before: ___  
Plan after: ___

---

## Exercise 3 — Partial indexes

Query:
`is_active = TRUE AND inventory.quantity > 0`

Before:
- Execution Time: ___ ms
- Plan: ___

After:
- Execution Time: ___ ms
- Plan: ___

Indexes:
- `idx_products_active_s4`
- `idx_inventory_positive_stock_s4`

---

## Exercise 4 — Covering index

Query:
monthly sales/report pattern on `orders`

Before:
- Execution Time: ___ ms
- Scan: ___

After:
- Execution Time: ___ ms
- Scan: ___

Expected optimization:
PostgreSQL may use an `Index Only Scan`, but this is not guaranteed. The planner decides based on table size, statistics, visibility map state, selectivity, and estimated cost.

---

## Important observation

A Sequential Scan is not automatically a problem. On a small table, scanning the whole table can be cheaper than using an index. The correct conclusion must come from the actual execution plan and measured time.
