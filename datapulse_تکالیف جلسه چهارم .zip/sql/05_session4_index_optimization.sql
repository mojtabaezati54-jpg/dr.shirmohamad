-- DataPulse Team 2 — Session 4
-- Smart indexing and query optimization
-- PostgreSQL 17
--
-- IMPORTANT:
-- Some exercises use shared tables owned by other DataPulse teams:
-- users, orders, order_items.
-- Run those sections after the shared schema is integrated.

-- ============================================================
-- EXERCISE 1 — Analyze the Top Customers query
-- ============================================================

-- Baseline: run BEFORE creating the new indexes.
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    u.user_id,
    u.name,
    SUM(o.total_amount) AS total_purchase,
    COUNT(o.order_id) AS order_count,
    ROUND(AVG(o.total_amount), 2) AS avg_order_amount
FROM users u
JOIN orders o
    ON o.user_id = u.user_id
WHERE o.status IN ('paid', 'completed', 'delivered')
GROUP BY u.user_id, u.name
ORDER BY total_purchase DESC
LIMIT 10;

-- After creating the index from indexes/04_session4_indexes.sql,
-- run the exact same EXPLAIN again.


-- ============================================================
-- EXERCISE 2 — Composite indexes for recurring queries
-- ============================================================

-- Query A: user + date range
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    order_id,
    user_id,
    created_at,
    total_amount,
    status
FROM orders
WHERE user_id = 1
  AND created_at >= CURRENT_DATE - INTERVAL '90 days'
ORDER BY created_at DESC;

-- Query B: status + date
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    order_id,
    created_at,
    total_amount,
    status
FROM orders
WHERE status = 'paid'
  AND created_at >= CURRENT_DATE - INTERVAL '90 days'
ORDER BY created_at DESC;

-- Query C: Team 2 product listing
-- If your schema uses category_id rather than category, use category_id.
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    product_id,
    name,
    category_id,
    price_amount
FROM products
WHERE store_id = 1
  AND category_id = 1
  AND is_active = TRUE
ORDER BY price_amount DESC;


-- ============================================================
-- EXERCISE 3 — Partial indexes
-- ============================================================

-- PostgreSQL partial indexes cannot use a condition based on
-- another table. Therefore:
--   "products active AND inventory quantity > 0"
-- cannot be expressed as one partial index on products if
-- quantity is stored in inventory.
--
-- Correct normalized design: use one partial index on products
-- for active products and one partial index on inventory for
-- positive stock.

EXPLAIN (ANALYZE, BUFFERS)
SELECT
    p.product_id,
    p.name,
    p.store_id,
    p.category_id,
    p.price_amount,
    i.quantity
FROM products p
JOIN inventory i
    ON i.product_id = p.product_id
WHERE p.is_active = TRUE
  AND i.quantity > 0
ORDER BY p.price_amount DESC;


-- ============================================================
-- EXERCISE 4 — Covering index
-- ============================================================

-- Monthly sales is a cross-team report because total_amount
-- belongs to orders. The following index is a covering index
-- for a common sales report pattern.
--
-- The key column created_at supports the date restriction/order.
-- INCLUDE keeps other selected/aggregated values available from
-- the index.

EXPLAIN (ANALYZE, BUFFERS)
SELECT
    store_id,
    created_at,
    total_amount
FROM orders
WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)
  AND created_at < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
ORDER BY created_at;


-- ============================================================
-- INDEX USAGE MONITORING
-- ============================================================

SELECT
    schemaname,
    relname AS table_name,
    indexrelname AS index_name,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes
ORDER BY idx_scan ASC, relname, indexrelname;


-- ============================================================
-- TABLE SCAN MONITORING
-- ============================================================

SELECT
    schemaname,
    relname AS table_name,
    seq_scan,
    seq_tup_read,
    idx_scan,
    idx_tup_fetch
FROM pg_stat_user_tables
ORDER BY seq_scan DESC;


-- ============================================================
-- SLOW QUERY MONITORING
-- Requires pg_stat_statements extension.
-- Run once per database if permitted.
-- ============================================================

CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

SELECT
    calls,
    ROUND(total_exec_time::numeric, 2) AS total_exec_ms,
    ROUND(mean_exec_time::numeric, 2) AS mean_exec_ms,
    rows,
    LEFT(query, 250) AS query_sample
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 20;


-- ============================================================
-- REINDEX examples
-- ============================================================

-- Rebuild one index:
-- REINDEX INDEX idx_orders_user_status_created;

-- Rebuild all indexes of one table:
-- REINDEX TABLE products;

-- Do not run REINDEX automatically as part of every deployment.
-- Use it when maintenance/diagnostics justify it.


-- ============================================================
-- OPTIONAL: verify index definitions
-- ============================================================

SELECT
    schemaname,
    tablename,
    indexname,
    indexdef
FROM pg_indexes
WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
ORDER BY tablename, indexname;
