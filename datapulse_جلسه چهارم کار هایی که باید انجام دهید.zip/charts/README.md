# Comparison chart

After executing the before/after queries, enter the real times from `reports/session4_homework_report.md` into a spreadsheet or plotting script and create a bar chart:

- X axis: Query
- Y axis: Execution Time (ms)
- Series 1: Before Index
- Series 2: After Index

Do not fabricate timing values. The chart must use actual PostgreSQL measurements.
