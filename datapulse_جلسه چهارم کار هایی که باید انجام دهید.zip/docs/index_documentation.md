# Session 4 — Index Documentation

| Index | Table | Type | Main query/purpose |
|---|---|---|---|
| `idx_orders_user_status_created_s4` | orders | B-Tree composite | Top customers / user + status + date filtering |
| `idx_orders_status_created_s4` | orders | B-Tree composite | Paid orders filtered by status and sorted by date |
| `idx_products_store_category_price_s4` | products | Partial B-Tree composite | Active products by store/category ordered by price |
| `idx_products_active_s4` | products | Partial B-Tree | Active product listing |
| `idx_inventory_positive_stock_s4` | inventory | Partial B-Tree | Products with positive stock |
| `idx_orders_monthly_sales_covering_s4` | orders | Covering B-Tree | Monthly sales report; enables possible Index Only Scan |

## Why two partial indexes for active + positive stock?

`is_active` belongs to `products`, while `quantity` belongs to `inventory`. PostgreSQL partial-index predicates cannot reference another table.

Therefore the normalized solution is two partial indexes plus the JOIN:
- `products WHERE is_active = TRUE`
- `inventory WHERE quantity > 0`

## Important

An index should only be kept if it benefits a real workload. Indexes increase storage and write/maintenance cost.
