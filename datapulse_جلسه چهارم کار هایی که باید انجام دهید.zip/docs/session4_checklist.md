# Session 4 Homework Checklist

- [x] All new indexes saved in repository
- [x] Each index documented with its target query
- [x] EXPLAIN ANALYZE queries prepared
- [x] Before/after report template prepared
- [x] Unused-index report prepared
- [x] Slow-query identification prepared
- [x] Monthly sales Materialized View prepared
- [x] Materialized View vs live aggregation comparison prepared
- [ ] Actual timings filled after running on PostgreSQL
- [ ] Comparison chart generated from actual timings
- [ ] Unused indexes reviewed after sufficient workload
- [ ] Slow queries selected from real statistics
