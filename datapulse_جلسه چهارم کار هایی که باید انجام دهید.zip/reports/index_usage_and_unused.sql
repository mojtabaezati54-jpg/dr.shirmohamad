-- Unused/low-use index report.
-- pg_stat_user_indexes counts index scans since statistics were reset
-- or since the database/server statistics started collecting.

SELECT
    schemaname,
    relname AS table_name,
    indexrelname AS index_name,
    idx_scan,
    idx_tup_read,
    idx_tup_fetch
FROM pg_stat_user_indexes
WHERE schemaname NOT IN ('pg_catalog', 'information_schema')
ORDER BY idx_scan ASC, relname, indexrelname;

-- Candidate indexes with zero scans:
SELECT
    schemaname,
    relname AS table_name,
    indexrelname AS index_name,
    idx_scan
FROM pg_stat_user_indexes
WHERE idx_scan = 0
  AND schemaname NOT IN ('pg_catalog', 'information_schema')
ORDER BY relname, indexrelname;

-- DO NOT immediately DROP a zero-use index.
-- It may be new, seasonal, or required by another workload.
-- Validate workload history first.
