# Session 4 Homework Report

## 1. Index documentation
See `docs/index_documentation.md`.

## 2. Before/after execution times

**Do not invent these values.** Copy `Execution Time` from actual PostgreSQL `EXPLAIN (ANALYZE, BUFFERS)` output.

| Query | Before (ms) | After (ms) | Improvement % |
|---|---:|---:|---:|
| Q1 Top customers | ___ | ___ | ___ |
| Q2 Status + date | ___ | ___ | ___ |
| Q3 Active products | ___ | ___ | ___ |
| Q4 Positive-stock products | ___ | ___ | ___ |
| Q5 Monthly sales | ___ | ___ | ___ |

Formula:

`Improvement % = ((Before - After) / Before) × 100`

## 3. Unused indexes

Run `reports/index_usage_and_unused.sql`.

| Index | idx_scan | Decision | Reason |
|---|---:|---|---|
| ___ | ___ | Keep / Investigate / Drop | ___ |

**Important:** zero `idx_scan` is not enough evidence by itself to drop an index.

## 4. Slow queries

Run `sql/06_slow_queries.sql`.

| Query | Calls | Mean time (ms) | Total time (ms) | Action |
|---|---:|---:|---:|---|
| ___ | ___ | ___ | ___ | ___ |

## 5. Monthly sales Materialized View

Live aggregation:
- Execution Time: ___ ms

Materialized View:
- Execution Time: ___ ms

Improvement:
`((Live - MV) / Live) × 100 = ___ %`

### Interpretation

The Materialized View stores the precomputed aggregation physically. Its main benefit appears when the report is expensive and queried frequently. Refreshing it has a cost, so it should be refreshed according to the application's freshness requirements.
