-- Session 4 Homework — EXPLAIN ANALYZE
-- IMPORTANT: execute the baseline section BEFORE creating indexes.
-- Save the output. Then create indexes and execute the same queries again.

-- Q1: Top customers
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    u.user_id,
    u.name,
    SUM(o.total_amount) AS total_purchase,
    COUNT(o.order_id) AS order_count,
    ROUND(AVG(o.total_amount), 2) AS avg_order_amount
FROM users u
JOIN orders o ON o.user_id = u.user_id
WHERE o.status IN ('paid', 'completed', 'delivered')
GROUP BY u.user_id, u.name
ORDER BY total_purchase DESC
LIMIT 10;

-- Q2: status + date
EXPLAIN (ANALYZE, BUFFERS)
SELECT order_id, created_at, total_amount, status
FROM orders
WHERE status = 'paid'
  AND created_at >= CURRENT_DATE - INTERVAL '90 days'
ORDER BY created_at DESC;

-- Q3: Team 2 active products
EXPLAIN (ANALYZE, BUFFERS)
SELECT product_id, name, category_id, price_amount
FROM products
WHERE store_id = 1
  AND category_id = 1
  AND is_active = TRUE
ORDER BY price_amount DESC;

-- Q4: active products + positive stock
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    p.product_id, p.name, p.price_amount, i.quantity
FROM products p
JOIN inventory i ON i.product_id = p.product_id
WHERE p.is_active = TRUE
  AND i.quantity > 0
ORDER BY p.price_amount DESC;

-- Q5: monthly sales pattern
EXPLAIN (ANALYZE, BUFFERS)
SELECT store_id, created_at, total_amount
FROM orders
WHERE created_at >= DATE_TRUNC('month', CURRENT_DATE)
  AND created_at < DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month'
ORDER BY created_at;
