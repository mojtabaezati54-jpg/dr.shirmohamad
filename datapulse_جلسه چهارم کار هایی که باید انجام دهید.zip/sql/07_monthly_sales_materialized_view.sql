-- Monthly sales Materialized View
-- Shared table: orders
--
-- Adjust the status list to exactly match your project's order statuses.

DROP MATERIALIZED VIEW IF EXISTS monthly_sales_report;

CREATE MATERIALIZED VIEW monthly_sales_report AS
SELECT
    DATE_TRUNC('month', created_at)::date AS sales_month,
    store_id,
    COUNT(*) AS order_count,
    SUM(total_amount) AS total_sales,
    AVG(total_amount) AS average_order_value
FROM orders
WHERE status IN ('paid', 'completed', 'delivered')
GROUP BY DATE_TRUNC('month', created_at)::date, store_id
ORDER BY sales_month, store_id;

-- Query the materialized result:
SELECT *
FROM monthly_sales_report
ORDER BY sales_month, store_id;

-- Index the materialized view:
CREATE INDEX IF NOT EXISTS idx_monthly_sales_report_month_store
ON monthly_sales_report (sales_month, store_id);

-- Refresh when source data changes:
REFRESH MATERIALIZED VIEW monthly_sales_report;

-- Measure the materialized view:
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    sales_month,
    store_id,
    total_sales,
    order_count,
    average_order_value
FROM monthly_sales_report
WHERE sales_month >= DATE_TRUNC('year', CURRENT_DATE)::date
ORDER BY sales_month, store_id;

-- Compare against the live aggregation:
EXPLAIN (ANALYZE, BUFFERS)
SELECT
    DATE_TRUNC('month', created_at)::date AS sales_month,
    store_id,
    COUNT(*) AS order_count,
    SUM(total_amount) AS total_sales,
    AVG(total_amount) AS average_order_value
FROM orders
WHERE status IN ('paid', 'completed', 'delivered')
  AND created_at >= DATE_TRUNC('year', CURRENT_DATE)
GROUP BY DATE_TRUNC('month', created_at)::date, store_id
ORDER BY sales_month, store_id;
