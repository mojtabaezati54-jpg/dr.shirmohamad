# DataPulse - Session 5: Analytical Database and Sales Data Mart

## ترتیب اجرا
1. sql/01_create_datamart.sql
2. sql/02_etl_load.sql
3. sql/03_analytical_queries.sql
4. sql/04_materialized_view.sql
5. sql/05_performance_comparison.sql

## پیش‌نیاز
این پکیج فرض می‌کند جداول OLTP زیر وجود دارند:
users, stores, categories, products, orders, order_items

## Grain
هر رکورد fact_sales برابر با یک محصول در یک آیتم سفارش است.
