# DataPulse Sales Data Mart

```text
                 dim_user
                    |
dim_product --- fact_sales --- dim_store
                    |
                 dim_time
```

Fact Sales:
user_key, product_key, store_key, time_key,
order_id, quantity, unit_price, discount_amount, total_amount
