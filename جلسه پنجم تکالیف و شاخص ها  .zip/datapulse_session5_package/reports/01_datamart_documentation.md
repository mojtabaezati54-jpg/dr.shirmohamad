# مستندات Data Mart

## هدف
جدا کردن بار تحلیلی از دیتابیس تراکنشی.

## Star Schema
- Fact: fact_sales
- Dimensions: dim_user, dim_product, dim_store, dim_time

## Grain
هر رکورد fact_sales = یک محصول در یک آیتم سفارش.

## ETL
Extract از users, stores, products, categories, orders, order_items.
Transform شامل مدیریت NULL، تولید time_key و محاسبه مبلغ فروش.
Load ابتدا Dimensionها و سپس Fact.
