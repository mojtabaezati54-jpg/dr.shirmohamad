# مقایسه OLTP و OLAP

OLTP برای ثبت تراکنش سریع و داده‌های نرمال است.
OLAP/Data Mart برای خواندن، Aggregate و تحلیل سریع طراحی می‌شود.

| Query | Execution Time |
|---|---:|
| OLTP Monthly Category Sales | ___ ms |
| Data Mart Monthly Category Sales | ___ ms |
| Materialized View | ___ ms |

اعداد واقعی را بعد از اجرای EXPLAIN ANALYZE وارد کنید.
