# نتایج اجرای واقعی

## ETL Validation
| Table | Row Count |
|---|---:|
| dim_user | |
| dim_product | |
| dim_store | |
| dim_time | |
| fact_sales | |

## Performance
| Query | Execution Time (ms) |
|---|---:|
| OLTP | |
| Data Mart | |
| Materialized View | |

این اعداد را از خروجی EXPLAIN ANALYZE وارد کنید.
