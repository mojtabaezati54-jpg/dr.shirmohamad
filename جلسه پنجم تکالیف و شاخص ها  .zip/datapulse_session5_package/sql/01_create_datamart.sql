BEGIN;
CREATE SCHEMA IF NOT EXISTS datamart;

CREATE TABLE IF NOT EXISTS datamart.dim_user (
 user_key BIGSERIAL PRIMARY KEY, user_id BIGINT NOT NULL UNIQUE,
 full_name VARCHAR(200), email VARCHAR(255), city VARCHAR(100),
 role VARCHAR(50), registration_date DATE
);

CREATE TABLE IF NOT EXISTS datamart.dim_product (
 product_key BIGSERIAL PRIMARY KEY, product_id BIGINT NOT NULL UNIQUE,
 product_name VARCHAR(255) NOT NULL, category_id BIGINT,
 category_name VARCHAR(150), brand VARCHAR(150),
 current_price NUMERIC(14,2), is_active BOOLEAN
);

CREATE TABLE IF NOT EXISTS datamart.dim_store (
 store_key BIGSERIAL PRIMARY KEY, store_id BIGINT NOT NULL UNIQUE,
 store_name VARCHAR(255) NOT NULL, city VARCHAR(100),
 owner_id BIGINT, registration_date DATE
);

CREATE TABLE IF NOT EXISTS datamart.dim_time (
 time_key INTEGER PRIMARY KEY, full_date DATE NOT NULL UNIQUE,
 day_of_month SMALLINT NOT NULL, day_of_week SMALLINT NOT NULL,
 day_name VARCHAR(20) NOT NULL, month_number SMALLINT NOT NULL,
 month_name VARCHAR(20) NOT NULL, quarter_number SMALLINT NOT NULL,
 year_number INTEGER NOT NULL, is_weekend BOOLEAN NOT NULL
);

CREATE TABLE IF NOT EXISTS datamart.fact_sales (
 sale_key BIGSERIAL PRIMARY KEY, order_id BIGINT NOT NULL,
 user_key BIGINT NOT NULL REFERENCES datamart.dim_user(user_key),
 product_key BIGINT NOT NULL REFERENCES datamart.dim_product(product_key),
 store_key BIGINT NOT NULL REFERENCES datamart.dim_store(store_key),
 time_key INTEGER NOT NULL REFERENCES datamart.dim_time(time_key),
 quantity INTEGER NOT NULL CHECK(quantity > 0),
 unit_price NUMERIC(14,2) NOT NULL CHECK(unit_price >= 0),
 discount_amount NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK(discount_amount >= 0),
 total_amount NUMERIC(14,2) NOT NULL CHECK(total_amount >= 0)
);

CREATE INDEX IF NOT EXISTS idx_fact_sales_time ON datamart.fact_sales(time_key);
CREATE INDEX IF NOT EXISTS idx_fact_sales_product ON datamart.fact_sales(product_key);
CREATE INDEX IF NOT EXISTS idx_fact_sales_store ON datamart.fact_sales(store_key);
CREATE INDEX IF NOT EXISTS idx_fact_sales_user ON datamart.fact_sales(user_key);
CREATE INDEX IF NOT EXISTS idx_fact_sales_order ON datamart.fact_sales(order_id);
COMMIT;
