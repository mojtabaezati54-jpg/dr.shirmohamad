BEGIN;
TRUNCATE TABLE datamart.fact_sales RESTART IDENTITY;
TRUNCATE TABLE datamart.dim_user RESTART IDENTITY CASCADE;
TRUNCATE TABLE datamart.dim_product RESTART IDENTITY CASCADE;
TRUNCATE TABLE datamart.dim_store RESTART IDENTITY CASCADE;
TRUNCATE TABLE datamart.dim_time;

INSERT INTO datamart.dim_time
SELECT TO_CHAR(d::date,'YYYYMMDD')::INTEGER, d::date,
 EXTRACT(DAY FROM d)::SMALLINT, EXTRACT(ISODOW FROM d)::SMALLINT,
 TO_CHAR(d,'FMDay'), EXTRACT(MONTH FROM d)::SMALLINT,
 TO_CHAR(d,'FMMonth'), EXTRACT(QUARTER FROM d)::SMALLINT,
 EXTRACT(YEAR FROM d)::INTEGER, EXTRACT(ISODOW FROM d) IN (6,7)
FROM generate_series(DATE '2024-01-01', DATE '2027-12-31', INTERVAL '1 day') g(d);

INSERT INTO datamart.dim_user(user_id,full_name,email,city,role,registration_date)
SELECT u.id, COALESCE(u.full_name,'Unknown'), COALESCE(u.email,'unknown@example.com'),
 COALESCE(u.city,'Unknown'), COALESCE(u.role,'customer'), u.created_at::date
FROM public.users u;

INSERT INTO datamart.dim_product(product_id,product_name,category_id,category_name,brand,current_price,is_active)
SELECT p.id,p.name,p.category_id,COALESCE(c.name,'Uncategorized'),
 COALESCE(p.brand,'Unknown'),COALESCE(p.price,0),COALESCE(p.is_active,TRUE)
FROM public.products p LEFT JOIN public.categories c ON c.id=p.category_id;

INSERT INTO datamart.dim_store(store_id,store_name,city,owner_id,registration_date)
SELECT s.id,s.name,COALESCE(s.city,'Unknown'),s.owner_id,s.created_at::date
FROM public.stores s;

INSERT INTO datamart.fact_sales(order_id,user_key,product_key,store_key,time_key,quantity,unit_price,discount_amount,total_amount)
SELECT o.id,du.user_key,dp.product_key,ds.store_key,
 TO_CHAR(o.created_at::date,'YYYYMMDD')::INTEGER,
 oi.quantity,oi.unit_price,COALESCE(oi.discount_amount,0),
 oi.quantity*oi.unit_price-COALESCE(oi.discount_amount,0)
FROM public.orders o
JOIN public.order_items oi ON oi.order_id=o.id
JOIN datamart.dim_user du ON du.user_id=o.user_id
JOIN datamart.dim_product dp ON dp.product_id=oi.product_id
JOIN datamart.dim_store ds ON ds.store_id=o.store_id
WHERE o.status IN ('paid','completed','delivered');

COMMIT;
ANALYZE datamart.dim_user; ANALYZE datamart.dim_product;
ANALYZE datamart.dim_store; ANALYZE datamart.dim_time; ANALYZE datamart.fact_sales;

SELECT 'dim_user' table_name,COUNT(*) row_count FROM datamart.dim_user
UNION ALL SELECT 'dim_product',COUNT(*) FROM datamart.dim_product
UNION ALL SELECT 'dim_store',COUNT(*) FROM datamart.dim_store
UNION ALL SELECT 'dim_time',COUNT(*) FROM datamart.dim_time
UNION ALL SELECT 'fact_sales',COUNT(*) FROM datamart.fact_sales;
