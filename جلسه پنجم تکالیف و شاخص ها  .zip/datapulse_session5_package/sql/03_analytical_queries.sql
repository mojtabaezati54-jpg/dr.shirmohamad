-- Q1 Monthly sales by category
SELECT dt.year_number,dt.month_number,dp.category_name,SUM(fs.total_amount) total_sales,SUM(fs.quantity) total_quantity
FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
JOIN datamart.dim_product dp ON dp.product_key=fs.product_key
GROUP BY dt.year_number,dt.month_number,dp.category_name ORDER BY 1,2,total_sales DESC;

-- Q2 Top 10 products in current month
SELECT dp.product_name,SUM(fs.quantity) units_sold,SUM(fs.total_amount) revenue
FROM datamart.fact_sales fs JOIN datamart.dim_product dp ON dp.product_key=fs.product_key
JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
WHERE dt.year_number=EXTRACT(YEAR FROM CURRENT_DATE) AND dt.month_number=EXTRACT(MONTH FROM CURRENT_DATE)
GROUP BY dp.product_name ORDER BY revenue DESC LIMIT 10;

-- Q3 New users and purchases
SELECT du.user_id,du.full_name,du.registration_date,COUNT(DISTINCT fs.order_id) order_count,COALESCE(SUM(fs.total_amount),0) total_purchase
FROM datamart.dim_user du LEFT JOIN datamart.fact_sales fs ON fs.user_key=du.user_key
WHERE DATE_TRUNC('month',du.registration_date)=DATE_TRUNC('month',CURRENT_DATE)
GROUP BY du.user_id,du.full_name,du.registration_date ORDER BY total_purchase DESC;

-- Q4 Store monthly growth
WITH m AS (
 SELECT ds.store_name,dt.year_number,dt.month_number,SUM(fs.total_amount) monthly_sales
 FROM datamart.fact_sales fs JOIN datamart.dim_store ds ON ds.store_key=fs.store_key
 JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
 GROUP BY 1,2,3
), p AS (
 SELECT *,LAG(monthly_sales) OVER(PARTITION BY store_name ORDER BY year_number,month_number) previous_sales FROM m
)
SELECT *,ROUND(CASE WHEN previous_sales>0 THEN ((monthly_sales-previous_sales)/previous_sales)*100 END,2) growth_percent
FROM p ORDER BY growth_percent DESC NULLS LAST;

-- Q5 Sales by weekday
SELECT dt.day_of_week,dt.day_name,SUM(fs.total_amount) total_sales,SUM(fs.quantity) units_sold
FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
GROUP BY 1,2 ORDER BY 1;

-- Q6 Average order value per user
WITH o AS (
 SELECT order_id,user_key,SUM(total_amount) order_total FROM datamart.fact_sales GROUP BY 1,2
)
SELECT du.full_name,COUNT(*) order_count,ROUND(AVG(o.order_total),2) average_order_value
FROM o JOIN datamart.dim_user du ON du.user_key=o.user_key
GROUP BY du.full_name ORDER BY average_order_value DESC;

-- Q7 Store share of total sales
WITH s AS (
 SELECT ds.store_name,SUM(fs.total_amount) store_sales
 FROM datamart.fact_sales fs JOIN datamart.dim_store ds ON ds.store_key=fs.store_key GROUP BY 1
)
SELECT store_name,store_sales,ROUND(100.0*store_sales/SUM(store_sales) OVER(),2) sales_share_percent
FROM s ORDER BY store_sales DESC;

-- Q8 Monthly trend and 3-month moving average
WITH m AS (
 SELECT dt.year_number,dt.month_number,SUM(fs.total_amount) total_sales
 FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key GROUP BY 1,2
)
SELECT *,ROUND(AVG(total_sales) OVER(ORDER BY year_number,month_number ROWS BETWEEN 2 PRECEDING AND CURRENT ROW),2) moving_average
FROM m ORDER BY 1,2;

-- Q9 Products above category average
WITH ps AS (
 SELECT dp.category_name,dp.product_name,SUM(fs.total_amount) revenue
 FROM datamart.fact_sales fs JOIN datamart.dim_product dp ON dp.product_key=fs.product_key GROUP BY 1,2
), r AS (
 SELECT *,AVG(revenue) OVER(PARTITION BY category_name) category_avg FROM ps
)
SELECT * FROM r WHERE revenue>category_avg ORDER BY category_name,revenue DESC;

-- Q10 Customer lifetime value ranking
WITH cs AS (
 SELECT du.user_id,du.full_name,SUM(fs.total_amount) lifetime_value,COUNT(DISTINCT fs.order_id) total_orders
 FROM datamart.fact_sales fs JOIN datamart.dim_user du ON du.user_key=fs.user_key GROUP BY 1,2
)
SELECT *,DENSE_RANK() OVER(ORDER BY lifetime_value DESC) customer_rank FROM cs ORDER BY customer_rank;

-- Q11 Regression forecast
WITH m AS (
 SELECT dt.year_number*12+dt.month_number month_index,SUM(fs.total_amount) total_sales
 FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key GROUP BY 1
)
SELECT REGR_SLOPE(total_sales,month_index) slope,REGR_INTERCEPT(total_sales,month_index) intercept,
 MAX(month_index)+1 next_month_index,
 REGR_INTERCEPT(total_sales,month_index)+REGR_SLOPE(total_sales,month_index)*(MAX(month_index)+1) predicted_next_month_sales
FROM m;
