DROP MATERIALIZED VIEW IF EXISTS datamart.mv_monthly_store_sales;
CREATE MATERIALIZED VIEW datamart.mv_monthly_store_sales AS
SELECT dt.year_number,dt.month_number,ds.store_key,ds.store_name,
 SUM(fs.total_amount) total_sales,SUM(fs.quantity) total_quantity,
 COUNT(DISTINCT fs.order_id) order_count,AVG(fs.total_amount) average_sale_amount
FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
JOIN datamart.dim_store ds ON ds.store_key=fs.store_key
GROUP BY dt.year_number,dt.month_number,ds.store_key,ds.store_name;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_monthly_store_sales_unique
ON datamart.mv_monthly_store_sales(year_number,month_number,store_key);
CREATE INDEX IF NOT EXISTS idx_mv_monthly_store_sales_revenue
ON datamart.mv_monthly_store_sales(total_sales DESC);

REFRESH MATERIALIZED VIEW datamart.mv_monthly_store_sales;
SELECT * FROM datamart.mv_monthly_store_sales ORDER BY year_number,month_number,total_sales DESC;
