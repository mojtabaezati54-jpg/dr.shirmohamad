-- OLTP
EXPLAIN (ANALYZE,BUFFERS)
SELECT DATE_TRUNC('month',o.created_at)::date sales_month,c.name category_name,
 SUM(oi.quantity*oi.unit_price-COALESCE(oi.discount_amount,0)) total_sales
FROM public.orders o JOIN public.order_items oi ON oi.order_id=o.id
JOIN public.products p ON p.id=oi.product_id
LEFT JOIN public.categories c ON c.id=p.category_id
WHERE o.status IN ('paid','completed','delivered')
GROUP BY DATE_TRUNC('month',o.created_at)::date,c.name
ORDER BY sales_month,total_sales DESC;

-- Data Mart
EXPLAIN (ANALYZE,BUFFERS)
SELECT dt.year_number,dt.month_number,dp.category_name,SUM(fs.total_amount) total_sales
FROM datamart.fact_sales fs JOIN datamart.dim_time dt ON dt.time_key=fs.time_key
JOIN datamart.dim_product dp ON dp.product_key=fs.product_key
GROUP BY dt.year_number,dt.month_number,dp.category_name
ORDER BY dt.year_number,dt.month_number,total_sales DESC;

-- Materialized View
EXPLAIN (ANALYZE,BUFFERS)
SELECT * FROM datamart.mv_monthly_store_sales
ORDER BY year_number,month_number,total_sales DESC;
